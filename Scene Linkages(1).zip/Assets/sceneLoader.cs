
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    
    public void playgame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().BuildIndex + 1);
    }
}
